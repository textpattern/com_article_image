function comArticleImageFormat(format, data) {
  var ids = [], text = "";
  if (format.match(/\{##\}/)) {
    data.forEach(function(img) {
      ids.push(img.id);
    });
    text = format.replace(/\{##\}/g, ids.join(","));
  } else data.forEach(function(img) {
      if (!img.id) format = imageLink ? imageLink : '<img src="{src}" />';
      let chunk = img.id ? format.replace(/\{#\}/g, img.id) : format;
      for (let [key, value] of Object.entries(img)) if (typeof value == "undefined") {
        chunk = chunk.replace(new RegExp("\\s+\\w+=[\"']{"+key+"}[\"']", "g"), "").replace(new RegExp("{"+key+"}", "g"), "");
      } else {
        let val = value.toString().replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
        chunk = chunk.replace(new RegExp("{"+key+"}", "g"), val)
      }
      text += chunk;
    });
  return text;
}

function comReadfiles(files, input) {
    let formData = new FormData(), count = 0;

    for (let i = 0; i < files.length; i++) {
        if (files[i].type.match(/^image\//) && files[i].size <= textpattern.prefs.max_file_size) {
            formData.append("thefile[]", files[i]);
            count++;
        }
    }

    let text = "Upload "+count+" image"+(count == 1 ? "" : "s")+"?";
    if (!count || !window.confirm(text)) return 0;

    formData.append("_txp_token", textpattern._txp_token);
    $(input).prop("disabled", true);

    $.ajax({
        url: "index.php?event=image&step=image_insert&app_mode=async&com=article_image",
        type: "POST",
        data: formData,
        async: true,
        success: function (data) {
            let text = typeof comArticleImage == "undefined" ? "" : comArticleImageFormat(imageTag, comArticleImage);
            textpattern.Relay.data.fileid = comArticleImage = [];
            $(input).prop("disabled", false);
            comInsertAtCursor(input, text);
            textpattern.Console.announce("uploadEnd");
        },
        cache: false,
        contentType: false,
        processData: false
    });
    return count;
}

function comInsertAtCursor (input, textToInsert) {
  // IE 8-10
  if (document.selection) {
    var ieRange = document.selection.createRange();
    ieRange.text = textToInsert;

    // Move cursor after the inserted text
    ieRange.collapse(false /* to the end */);
    ieRange.select();

    return;
  }

  const [start, end] = [input.selectionStart, input.selectionEnd];
  input.setRangeText(textToInsert, start, end, "end");
  // Notify any possible listeners of the change
  const e = new Event("input", {"bubbles":true, "cancelable":false});
  input.dispatchEvent(e);
}

window.comArticleImagePreview = function (input) {
    let createObjectURL = (window.URL || window.webkitURL || {}).createObjectURL

    if (createObjectURL && input.files.length) {
        $("#article-file-preview").empty();
        $("#article-file-reset").removeClass("invisible");
        $(input.files).each(function () {
            let valid = this.type.match(/^image\//) && this.size <= textpattern.prefs.max_file_size;
            let src = valid ? this.url || createObjectURL(this) : null;
            let img = valid ? "<img src=\'" + src + "\' />" : "<del>"+textpattern.encodeHTML(this.name)+"</del>";
            $("#article-file-preview").append("<p>"+img+"</p>");

            if (!valid)
              textpattern.Console.addMessage(['<strong>'+textpattern.encodeHTML(this.name)+'</strong> - '+textpattern.gTxt('upload_err_form_size'), 1], 'comImageUpload');
        });
        textpattern.Console.announce('comImageUpload');
    }
}

$("#body, #excerpt").on("dragover", function(evt) {
    e = evt.originalEvent;
    if (e.dataTransfer.types.includes("Files")) {
        e.stopPropagation();
        e.preventDefault();
        e.dataTransfer.dropEffect = "copy";
    }
}).on("drop", function(evt) {
    let e = evt.originalEvent, count = 0;
    if (document.getElementById("article-file-input") && e.dataTransfer.files.length) {//console.log(e.dataTransfer.files)
        count = comReadfiles(e.dataTransfer.files, this);
    }
    if (count)
        e.preventDefault();
    else {
        let img = $("<div>"+e.dataTransfer.getData("text/html")+"</div>").find("img");
        var text = "";
        if (img.length) {
          img.each(function( index ) {
            let me = $(this);
            if (me.attr("src") || me.attr("srcset")) {
              let atts = {
                src: me.attr("src"),
                srcset: me.attr("srcset"),
                sizes: me.attr("sizes"),
                alt: me.attr("alt"),
                title: me.attr("title"),
                h: me.attr("height"),
                w: me.attr("width")
              };
              if (imageLink) {
                text += comArticleImageFormat(imageLink, [atts]);
              } else {
                let tmpimg = $("<img />").attr(atts);
                text += tmpimg.prop("outerHTML");
                //$("#article-file-preview").append(tmpimg);
              }
            }
          });
        }
        if (text || !this.setRangeText) {
          e.preventDefault();
          comInsertAtCursor(this, text || e.dataTransfer.getData("text/plain"));
        }
    }
}).sortable({
  receive: function(e) {
    let img = $(e.originalEvent.target), data = img.data();
    let src = imageDir+"/"+data.id+data.ext;
    let ins = [{alt: img.attr("alt"), id: data.id, w: data.width, h: data.height, src: src}];
    comInsertAtCursor(this, comArticleImageFormat(imageTag, ins))
  }
});

$("#txp-image-group-content").on("dragover", "#article-file-input", function(evt) {
  e = evt.originalEvent;
  if (e.dataTransfer.types.includes("Files")) return;
//  e.stopPropagation();
  evt.preventDefault();
  e.dataTransfer.dropEffect = "copy";
}).on("drop", "#article-file-input", function(e) {
  const dragged = e.originalEvent.dataTransfer.getData("text/html") || e.originalEvent.target;
  let imgs = $("<div>"+dragged+"</div>").find("img");
  let count = imgs.length;
  if (!count) return;

  let input = document.getElementById("article-file-input");
  let transfer = new DataTransfer();
  e.preventDefault();
    imgs.each(function() {
      let src = new URL($(this).attr("src"));
      let filename = src.pathname.split('/').pop();//$(this).attr("src").split('/').pop().split('#')[0].split('?')[0];
      fetch(src)
      .then(res => res.blob()) // Gets the response and returns it as a blob
      .then(blob => {
        blob.name = filename;
        let file = new File([blob], filename, {type:blob.type, lastModified:new Date().getTime()});
        file.url = src;
        transfer.items.add(file);
        if (transfer.files.length == count) {
          input.files = transfer.files;
          $(input).trigger("change");}
      });
    })
}).on("change", "#article-file-input", function(e) {
  comArticleImagePreview(this);
}).on("click", "#article-file-reset", function(e) {
    e.preventDefault();
    $("#article-file-input").val("");
    $("#article-file-preview").empty();
    $("#article-file-reset").addClass("invisible");
}).on("click", "#article-file-select .destroy", function(e) {
  e.preventDefault();
  $(this).parent().remove();
}).on("click", ".sortable .destroy", function(e) {
    e.preventDefault();
    let p = $(this).parent(), val = $("#article-file-name").val();
    if (!(val === "" || p.is(":is([title*='"+$.escapeSelector(val)+"' i])"))) p.hide();
    p.removeClass("sortable").clone().appendTo("#article-file-select");
    p.remove();
    $("#txp-image-group-content").triggerHandler("sortstop");
}).on("dragstart", "#article-file-container a, #article-file-select a", function(e) {
//      console.log(e.originalEvent)
    let dragged = e.originalEvent.dataTransfer.getData("text/html") || e.originalEvent.target;
    let imgs = $(dragged).find("img");
    let data = [];
    imgs.each(function() {
      let src = $(this).data("id") ? imageDir+"/"+$(this).data("id")+$(this).data("ext") : $(this).attr("src");
      data.push({alt: $(this).attr("alt"), id: $(this).data("id"), w: $(this).data("width"), h: $(this).data("height"), src: src});
    })
    e.originalEvent.dataTransfer.setData("text/plain", comArticleImageFormat(imageTag, data));
    e.originalEvent.dataTransfer.setData("text/html", "");
}).on("sortstop", function(e, only) {
    let myContainer = $("#article-file-container");
    var list = /*$("#article-image").val().split(",").filter(isNaN);*/[];
    myContainer.children("p.sortable").each(function() {
      list.push($(this).data("id"));
    });
    if (only !== true) {
      $("#article-image").val(list.join());
    } else {
      let select = $("#article-file-select");
      list.forEach(function(id) {
        select.children("p[data-id='"+$.escapeSelector(id)+"']").remove();
      })
    }
    $("#article-file-update").addClass("invisible");
    myContainer.removeClass("disabled");
    $(this).sortable("refresh");
}).on("addimage", "#article-file-select p", function() {
  let myContainer = $("#article-file-container");
  $(this).addClass("sortable").appendTo(myContainer);
  myContainer.scrollTop(myContainer.prop("scrollHeight"));
  $("#txp-image-group-content").triggerHandler("sortstop");
}).on("click", "#article-file-select a", function(e) {
  e.preventDefault();
  $(this).parent().trigger("addimage");
}).on("click", "#article-file-add", function(e) {
  e.preventDefault();
  $("#article-file-select>p:visible").trigger("addimage");
}).on("click", "#article-file-update", function(e) {
  e.preventDefault();
  let val = $("#article-image").val();
  if (val !== "") {
    $.ajax({
        url: "index.php?event=article&step=com_article_image_update",
        type: "POST",
        data: {image_name: "", ids: val, _txp_token: textpattern._txp_token},
        success: function (data) {
            $("#article-file-container").html($(data.join("")));
            $("#txp-image-group-content").triggerHandler("sortstop", true);
        }
    });
  } else {
    $("#article-file-container").empty();
  }
}).on("keydown", "#article-file-name", function(e) {
    switch (e.originalEvent.key) {
      case "Escape":
        this.value = "";
        this.filterValue = null;
        this.setCustomValidity("");
        $("#article-file-select").empty();
        break;
    }
    if (e.originalEvent.key !== "Enter") return;
    e.preventDefault();
    this.setCustomValidity("");
    this.filterValue = this.value;
//    let id = new URL(window.location.toLocaleString()).searchParams.get('ID');
    $.ajax({
        url: "index.php?event=article&step=com_article_image_fetch",
        type: "POST",
        data: {image_name: this.value, ids: $("#article-image").val(), _txp_token: textpattern._txp_token},
        success: function (data) {
            $("#article-file-select").html($(data.join("")));
        }
    });
}).on("input", "#article-file-name", function(e) {
    if(this.value.includes(this.filterValue)) this.setCustomValidity("");
    else this.setCustomValidity(this.filterValue);
    let val = this.value,
      sel = "[title*='"+$.escapeSelector(val)+"' i]";
    
    $("#article-file-select").find("p").each(function() {
      if (val === "" || $(this).is(sel)) $(this).show();
      else $(this).hide();
    });
}).on("input", "#article-image", function() {
  $("#article-file-container").addClass("disabled");
  $("#article-file-update").removeClass("invisible");
}).on("mousedown", ".sortable", function(e) {
  if (e.originalEvent.shiftKey) $(e.delegateTarget).sortable("disable");
}).on("dragend", "#article-file-container a", function(e) {
    $(e.delegateTarget).sortable("enable");
}).sortable({
    items: ".sortable",
    connectWith: "#body, #excerpt"/*,
    remove: function() {$(this).sortable("cancel")}*/
});
