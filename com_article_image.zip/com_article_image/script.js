function comArticleImageFormat(format, data) {
  var ids = [], text = "";
  if (format.match(/\{##\}/)) {
    data.forEach(function(img) {
      ids.push(img.id);
    });
    text = format.replace(/\{##\}/g, ids.join(","));
  } else data.forEach(function(img) {
      if (!img.id) format = imageLink ? imageLink : '<img src="{src}" />';
      let chunk = img.id ? format.replace(/\{#\}/g, img.id) : format;
      for (let [key, value] of Object.entries(img)) if (typeof value == "undefined") {
        chunk = chunk.replace(new RegExp("\\s+\\w+=[\"']{"+key+"}[\"']", "g"), "").replace(new RegExp("{"+key+"}", "g"), "");
      } else {
        let val = value.toString().replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
        chunk = chunk.replace(new RegExp("{"+key+"}", "g"), val)
      }
      text += chunk;
    });
  return text;
}

function comReadfiles(files, input) {
    var formData = new FormData(), count = 0;

    for (var i = 0; i < files.length; i++) {
        if (files[i].type.match(/^image\//) && files[i].size <= textpattern.prefs.max_file_size) {
            formData.append("thefile[]", files[i]);
            count++;
        }
    }

    var text = "Upload "+count+" image"+(count == 1 ? "" : "s")+"?";
    if (!count || !window.confirm(text)) return 0;

    formData.append("_txp_token", textpattern._txp_token);
    $(input).prop("disabled", true);

    $.ajax({
        url: "index.php?event=image&step=image_insert&app_mode=async&com=article_image",
        type: "POST",
        data: formData,
        async: true,
        success: function (data) {
            var text = typeof comArticleImage == "undefined" ? "" : comArticleImageFormat(imageTag, comArticleImage);
            textpattern.Relay.data.fileid = comArticleImage = [];
            $(input).prop("disabled", false);
            comInsertAtCursor(input, text);
            textpattern.Console.announce("uploadEnd");
        },
        cache: false,
        contentType: false,
        processData: false
    });
    return count;
}

$("#body, #excerpt").on("dragover", function(evt) {
    e = evt.originalEvent;
    if (e.dataTransfer.types.includes("Files")) {
        e.stopPropagation();
        e.preventDefault();
        e.dataTransfer.dropEffect = "copy";
    }
}).on("drop", function(evt) {
    var e = evt.originalEvent, count = 0
    if (e.dataTransfer.files.length) {//console.log(e.dataTransfer.files)
        count = comReadfiles(e.dataTransfer.files, this);
    }
    if (count)
        e.preventDefault();
    else {
        let img = $("<div>"+e.dataTransfer.getData("text/html")+"</div>").find("img");
        var text = "";
        if (img.length) {
          img.each(function( index ) {
            var me = $(this);
            if (me.attr("src") || me.attr("srcset")) {
              var atts = {
                src: me.attr("src"),
                srcset: me.attr("srcset"),
                sizes: me.attr("sizes"),
                alt: me.attr("alt"),
                title: me.attr("title"),
                h: me.attr("height"),
                w: me.attr("width")
              };
              if (imageLink) {
                text += comArticleImageFormat(imageLink, [atts]);
              }
              else {
                var tmpimg = $("<img />").attr(atts);
                text += tmpimg.prop("outerHTML");
                //$("#article-file-preview").append(tmpimg);
              }
            }
          });
        }
        if (text || !this.setRangeText) {
          e.preventDefault();
          comInsertAtCursor(this, text || e.dataTransfer.getData("text/plain"));
        }
    }
});

$("#txp-image-group-content").on("change", "#article-file-input", function(e) {
  comArticleImagePreview(this);
}).on("click", "#article-file-reset", function(e) {
    e.preventDefault();
    $("#article-file-input").val("");
    $("#article-file-preview").empty();
    $("#article-file-reset").css("visibility", "hidden");
}).on("click", "#article-file-add", function(e) {
  e.preventDefault();
  $("#article-file-select>p.matching>a").trigger("click");
}).on("click", "#article-file-select .destroy", function(e) {
  e.preventDefault();
  $(this).parent().remove();
}).on("click", ".sortable .destroy", function(e) {
    e.preventDefault();
    let p = $(this).parent(), val = $("#article-file-name").val();
    if (val === "" || p.is(":is([title*='"+$.escapeSelector(val)+"' i])")) p.addClass("matching");
    else p.removeClass("matching");
    p.removeClass("sortable").clone().appendTo("#article-file-select");
    p.remove();
    $("#txp-image-group-content").trigger("sortupdate").sortable("refresh");
}).on("dragstart", "#article-file-container a, #article-file-select a", function(e) {
//      console.log(e.originalEvent)
    var dragged = e.originalEvent.dataTransfer.getData("text/html") || e.originalEvent.target;
    var imgs = $(dragged).find("img");
    var text = "", data = [];
    imgs.each(function() {
      let src = $(this).data("id") ? imageDir+"/"+$(this).data("id")+$(this).data("ext") : $(this).attr("src");
      data.push({alt: $(this).attr("alt"), id: $(this).data("id"), w: $(this).data("width"), h: $(this).data("height"), src: src});
    })
    text = comArticleImageFormat(imageTag, data);
    e.originalEvent.dataTransfer.setData("text/plain", text);
    e.originalEvent.dataTransfer.setData("text/html", "");
}).on("sortupdate", function( event ) {
    var myContainer = $("#article-file-container"),
      list = /*$("#article-image").val().split(",").filter(isNaN);*/[];
    myContainer.children("p.sortable").each(function() {
      list.push($(this).data("id"));
    });
    $("#article-image").val(list.join());
}).on("click", "#article-file-select a", function(e) {
    e.preventDefault();
    $(this).parent().addClass("sortable").appendTo("#article-file-container");
    $("#txp-image-group-content").trigger("sortupdate").sortable("refresh");
}).on("keydown", "#article-file-name", function(e) {
    switch (e.originalEvent.key) {
      case "Escape":
        this.value = "";
        this.filterValue = null;
        this.setCustomValidity("");
        $("#article-file-select").empty();
        break;/*
      case "ArrowDown":
      case "PageDown":
        var limit = e.originalEvent.key == "ArrowDown" ? 1 : imageLim;
        let visible = $("#article-file-select").children(":visible");
        if (visible.length >= imageLim) {
          let next = visible.last().nextAll(".matching").length;
          visible.slice(0, limit < next ? limit : next).addClass("hidden");
        }
        break;
      case "ArrowUp":
      case "PageUp":
        var limit = e.originalEvent.key == "ArrowUp" ? 1 : imageLim;
        $("#article-file-select").children(".matching.hidden").slice(-limit).removeClass("hidden");
        break;*/
    }
    if (e.originalEvent.key !== "Enter") return;
    e.preventDefault();
    this.setCustomValidity("");
    this.filterValue = this.value;
//    let id = new URL(window.location.toLocaleString()).searchParams.get('ID');
    $.ajax({
        url: "index.php?event=article&step=com_article_image_fetch",
        type: "POST",
        data: {image_name: this.value, ids: $("#article-image").val(), _txp_token: textpattern._txp_token},
        async: true,
        success: function (data) {
            $("#article-file-select").html($(data.join("")));
        },
        cache: false
    });
}).on("input", "#article-file-name", function(e) {
    if(this.value.includes(this.filterValue)) this.setCustomValidity("");
    else this.setCustomValidity(this.filterValue);
    let val = this.value,
      sel = "[title*='"+$.escapeSelector(val)+"' i]";
    
    $("#article-file-select").find("p").each(function() {
      if (val === "" || $(this).is(sel)) $(this).addClass("matching").removeClass("hidden");
      else $(this).removeClass("matching");
    });
});

$("#txp-image-group-content").on("dragend", "#article-file-container a", function(e) {
    $("#txp-image-group-content").sortable("enable");
}).sortable({
    items: ".sortable",
    out: function (event, ui) {
        if (!!droppedOutside) $(this).sortable("disable");
    },
    over: function (event, ui) {
        $(this).sortable("enable");
    },
    beforeStop: function (event, ui) {droppedOutside = false;
    },
    start: function (event, ui) {droppedOutside = true;
    }
});

function comInsertAtCursor (input, textToInsert) {
  // IE 8-10
  if (document.selection) {
    const ieRange = document.selection.createRange();
    ieRange.text = textToInsert;

    // Move cursor after the inserted text
    ieRange.collapse(false /* to the end */);
    ieRange.select();

    return;
  }

  const [start, end] = [input.selectionStart, input.selectionEnd];
  input.setRangeText(textToInsert, start, end, 'select');
  // Notify any possible listeners of the change
  const e = new Event("input", {"bubbles":true, "cancelable":false});
  input.dispatchEvent(e);
}

window.comArticleImagePreview = function (input) {
    let createObjectURL = (window.URL || window.webkitURL || {}).createObjectURL

    if (createObjectURL && input.files.length) {
        $("#article-file-preview").empty();
        $("#article-file-reset").css("visibility", "visible");
        $(input.files).each(function () {
            var valid = this.type.match(/^image\//) && this.size <= textpattern.prefs.max_file_size,
            img = valid ? "<img src=\'" + createObjectURL(this) + "\' />" : "<del>"+textpattern.encodeHTML(this.name)+"</del>";
            $("#article-file-preview").append("<p>"+img+"</p>");

            if (!valid)
              textpattern.Console.addMessage(['<strong>'+textpattern.encodeHTML(this.name)+'</strong> - '+textpattern.gTxt('upload_err_form_size'), 1], 'comImageUpload');
        });
        textpattern.Console.announce('comImageUpload');
    }
}
