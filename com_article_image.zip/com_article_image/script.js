function comArticleImageFormat(format, data) {
  var ids = [], text = "";
  if (format.match(/\{##\}/)) {
    data.forEach(function(img) {
      ids.push(img.id);
    });
    text = format.replace(/\{##\}/g, ids.join(","));
  } else data.forEach(function(img) {
      if (!img.id) format = imageLink ? imageLink : '<img src="{src}" />';
      let chunk = img.id ? format.replace(/\{#\}/g, img.id) : format;
      for (let [key, value] of Object.entries(img)) if (typeof value == "undefined") {
        chunk = chunk.replace(new RegExp("\\s+\\w+=[\"']{"+key+"}[\"']", "g"), "").replace(new RegExp("{"+key+"}", "g"), "");
      } else {
        let val = value.toString().replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
        chunk = chunk.replace(new RegExp("{"+key+"}", "g"), val)
      }
      text += chunk;
    });
  return text;
}

function comReadfiles(files, input) {
    let formData = new FormData(), count = 0;

    for (let i = 0; i < files.length; i++) {
        if (files[i].type.match(/^image\//) && files[i].size <= textpattern.prefs.max_file_size) {
            formData.append("thefile[]", files[i]);
            count++;
        }
    }

    let text = "Upload "+count+" image"+(count == 1 ? "" : "s")+"?";
    if (!count || !window.confirm(text)) return 0;

    formData.append("_txp_token", textpattern._txp_token);
    $(input).prop("disabled", true);

    $.ajax({
        url: "index.php?event=image&step=image_insert&app_mode=async&com=article_image",
        type: "POST",
        data: formData,
        async: true,
        success: function (data) {
            let text = typeof comArticleImage == "undefined" ? "" : comArticleImageFormat(imageTag, comArticleImage);
            textpattern.Relay.data.fileid = comArticleImage = [];
            $(input).prop("disabled", false);
            comInsertAtCursor(input, text);
            textpattern.Console.announce("uploadEnd");
        },
        cache: false,
        contentType: false,
        processData: false
    });
    return count;
}

function comInsertAtCursor (input, textToInsert) {
  // IE 8-10
  if (document.selection) {
    var ieRange = document.selection.createRange();
    ieRange.text = textToInsert;

    // Move cursor after the inserted text
    ieRange.collapse(false /* to the end */);
    ieRange.select();

    return;
  }

  const [start, end] = [input.selectionStart, input.selectionEnd];
  input.setRangeText(textToInsert, start, end, "end");
  // Notify any possible listeners of the change
  const e = new Event("input", {"bubbles":true, "cancelable":false});
  input.dispatchEvent(e);
}

window.comArticleImagePreview = function (input) {
    let createObjectURL = (window.URL || window.webkitURL || {}).createObjectURL

    if (createObjectURL && input.files.length) {
        $("#article-file-reset").removeClass("invisible");
        $(input.files).each(function () {
            let valid = this.type.match(/^image\//) && this.size <= textpattern.prefs.max_file_size;
            if (!valid) {
              textpattern.Console.addMessage(['<strong>'+textpattern.encodeHTML(this.name)+'</strong> - '+textpattern.gTxt('upload_err_form_size'), 1], 'comImageUpload');
            } else {
              let src = createObjectURL(this);
              p = comArticleImageTile({src: src, title: this.name}, {file: this});
              $("#article-file-preview").append(p);
            }
        });
        textpattern.Console.announce('comImageUpload');
    }
}

function comArticleImageTile(atts, pAtts) {
  let button = $("<button class=\"destroy\" title=\""+textpattern.gTxt("delete")+"\"><span class=\"ui-icon ui-icon-close\">"+textpattern.gTxt("delete")+"</span></button>");
  let img = $("<img />").attr("loading", "lazy").attr(atts), a = $("<a />").attr({"href": atts.src}).append(img);
  let p = document.createElement("p");
  for (let prop in pAtts) {p[prop] = pAtts[prop];}
  return $(p).append(a).append(button);    
}

$("#article_form").on("submit", function() {
  let src = [], dataTransfer = new DataTransfer();

  $("#article-file-preview").find("p").each(function() {
    if (this.file) {
      dataTransfer.items.add(this.file);
    } else $(this).find("img").each(function(){
      let url = $(this).attr("src"), alt = $(this).attr("alt"), title = $(this).attr("title");
      src.push({url: url, alt: alt, title: title});
    });
  });

  document.getElementById("article-file-import").value = JSON.stringify(src);
  document.getElementById("article-file-input").files = dataTransfer.files;
});

$("#body, #excerpt").on("dragover", function(evt) {
    e = evt.originalEvent;
    if (e.dataTransfer.types.includes("Files")) {
        e.stopPropagation();
        e.preventDefault();
        e.dataTransfer.dropEffect = "copy";
    }
}).on("drop", function(evt) {
    let e = evt.originalEvent, count = 0;
    if (document.getElementById("article-file-input") && e.dataTransfer.files.length) {//console.log(e.dataTransfer.files)
        count = comReadfiles(e.dataTransfer.files, this);
    }
    if (count)
        e.preventDefault();
    else {
        let img = $("<div>"+e.dataTransfer.getData("text/html")+"</div>").find("img");
        var text = "";
        if (img.length) {
          img.each(function( index ) {
            let me = $(this);
            if (me.attr("src") || me.attr("srcset")) {
              let atts = {
                src: me.attr("src"),
                srcset: me.attr("srcset"),
                sizes: me.attr("sizes"),
                alt: me.attr("alt"),
                title: me.attr("title"),
                h: me.attr("height"),
                w: me.attr("width")
              };
              if (imageLink) {
                text += comArticleImageFormat(imageLink, [atts]);
              } else {
                let tmpimg = $("<img />").attr(atts);
                text += tmpimg.prop("outerHTML");
              }
            }
          });
        }
        if (text || !this.setRangeText) {
          e.preventDefault();
          comInsertAtCursor(this, text || e.dataTransfer.getData("text/plain"));
        }
    }
}).sortable({
  receive: function(e) {
    let img = $(e.originalEvent.target), data = img.data();
    let src = imageDir+"/"+data.id+data.ext;
    let ins = [{alt: img.attr("alt"), id: data.id, w: data.width, h: data.height, src: src}];
    comInsertAtCursor(this, comArticleImageFormat(imageTag, ins))
  }
});

$("#txp-image-group-content").on("dragenter", "#article-file-input-label", function(evt) {
  $(this).addClass("dragging");
}).on("dragleave", "#article-file-input-label", function(evt) {
  $(this).removeClass("dragging");
}).on("dragover", "#article-file-input-label", function(evt) {
    evt.preventDefault();
    evt.originalEvent.dataTransfer.dropEffect = "copy";
}).on("drop", "#article-file-input-label", function(evt) {//console.log(evt.originalEvent.dataTransfer)
  $(this).removeClass("dragging");
  evt.preventDefault();
  evt.stopPropagation();
  let e = evt.originalEvent;
  if (e.dataTransfer.types.includes("Files")) {
    comArticleImagePreview(e.dataTransfer);
  }
  const dragged = e.dataTransfer.getData("text/html") || e.target;
  let imgs = $("<div>"+dragged+"</div>").find("img");
  if (imgs.length) {
    imgs.each(function() {
      let atts = {src: $(this).attr("src"), alt: $(this).attr("alt"), title: $(this).attr("title")};
      let p = comArticleImageTile(atts, {});    
      $("#article-file-preview").append(p);
    });
  }
  $("#article-file-reset").trigger("refresh");
}).on("change", "#article-file-input", function(e) {
  comArticleImagePreview(this);
  this.value = null;
}).on("refresh", "#article-file-reset", function() {
  if ($("#article-file-preview p").length) $(this).removeClass("invisible");
  else $(this).addClass("invisible");
}).on("click", "#article-file-reset", function(e) {
    e.preventDefault();
    $("#article-file-import").val("[]");
    $("#article-file-input").val(null);
    $("#article-file-preview").empty();
    $(this).addClass("invisible");
}).on("click", "#article-file-empty", function(e) {
  e.preventDefault();
  $("#article-file-select p").remove(":visible");
  $("#article-file-select").data("count", 0);
  $("#article-file-action").addClass("invisible");
}).on("click", ".com-image-container p button.destroy", function(e) {
  e.preventDefault();
  $(this).parent().remove();
}).on("click", "#article-file-container .destroy", function(e) {
    $("#txp-image-group-content").triggerHandler("sortstop");
}).on("click", "#article-file-preview .destroy", function(e) {
    $("#article-file-reset").trigger("refresh");
}).on("click", "#article-file-select .destroy", function(e) {
    let count = $("#article-file-select").data("count");
    $("#article-file-select").data("count", count - 1).trigger("refresh");
}).on("dragstart", "#article-file-container a, #article-file-select a", function(e) {
    let dragged = e.originalEvent.dataTransfer.getData("text/html") || e.originalEvent.target;
    let imgs = $(dragged).find("img");
    let data = [];
    imgs.each(function() {
      let src = $(this).data("id") ? imageDir+"/"+$(this).data("id")+$(this).data("ext") : $(this).attr("src");
      data.push({alt: $(this).attr("alt"), id: $(this).data("id"), w: $(this).data("width"), h: $(this).data("height"), src: src});
    })
    e.originalEvent.dataTransfer.setData("text/plain", comArticleImageFormat(imageTag, data));
    e.originalEvent.dataTransfer.setData("text/html", "");
}).on("sortstop", function(e, only) {
    let myContainer = $("#article-file-container");
    var list = /*$("#article-image").val().split(",").filter(isNaN);*/[];
    myContainer.children("p.sortable").each(function() {
      list.push($(this).data("id"));
    });
    if (only !== true) {
      $("#article-image").val(list.join());
    } else {
      let select = $("#article-file-select");
      list.forEach(function(id) {
        select.children("p[data-id='"+$.escapeSelector(id)+"']").remove();
      })
    }
    $("#article-file-update").addClass("invisible");
    myContainer.removeClass("disabled");
    $(this).sortable("refresh");
}).on("click", "#article-file-select a", function(e) {
  e.preventDefault();
  if (e.originalEvent) {
    let count = $("#article-file-select").data("count");
    $("#article-file-select").data("count", count - 1).trigger("refresh");
  }
  let myContainer = $("#article-file-container");
  $(this).parent().addClass("sortable").appendTo(myContainer);
  myContainer.scrollTop(myContainer.prop("scrollHeight"));
  $("#txp-image-group-content").triggerHandler("sortstop");
}).on("click", "#article-file-add", function(e) {
  e.preventDefault();
  $("#article-file-select>p:visible>a").trigger("click");
  $("#article-file-select").data("count", 0).trigger("refresh");
}).on("click", "#article-file-update", function(e) {
  e.preventDefault();
  let val = $("#article-image").val();
  if (val !== "") {
    $.ajax({
        url: "index.php?event=article&step=com_article_image_update",
        type: "POST",
        data: {image_name: "", ids: val, _txp_token: textpattern._txp_token},
        success: function (data) {
            $("#article-file-container").html($(data.join("")));
            $("#txp-image-group-content").triggerHandler("sortstop", true);
        }
    });
  } else {
    $("#article-file-container").empty();
  }
}).on("keydown", "#article-file-name", function(e) {
    if (e.originalEvent.key === "Escape") {
      $("#article-file-select").empty().data("count", 0).trigger("refresh");
      $("#article-file-name").each(function() {
        this.value = "";
        this.filterValue = null;
        this.setCustomValidity("");
      }).trigger("input");
    }
    if (e.originalEvent.key !== "Enter") return;
    e.preventDefault();
    this.setCustomValidity("");
    this.filterValue = this.value;
    $.ajax({
        url: "index.php?event=article&step=com_article_image_fetch",
        type: "POST",
        data: {image_name: this.value, ids: $("#article-image").val(), _txp_token: textpattern._txp_token},
        success: function (data) {
            $("#article-file-select").html($(data.join(""))).data("count", data.length).trigger("refresh");
        }
    });
}).on("input", "#article-file-name", function(e) {
    if(this.value.includes(this.filterValue)) this.setCustomValidity("");
    else this.setCustomValidity(this.filterValue);
    let val = this.value, count = 0,
      sel = "[title*='"+$.escapeSelector(val)+"' i]";
    
    $("#article-file-select").find("p").each(function() {
      if (val === "" || $(this).is(sel)) {$(this).show(); count++;}
      else $(this).hide();
    });
    $("#article-file-select").data("count", count).trigger("refresh");
}).on("refresh", "#article-file-select", function() {
  if ($(this).data("count")) $("#article-file-action").removeClass("invisible");
  else $("#article-file-action").addClass("invisible");
}).on("input", "#article-image", function() {
  $("#article-file-container").addClass("disabled");
  $("#article-file-update").removeClass("invisible");
}).on("mousedown", ".sortable", function(e) {
  if (e.originalEvent.shiftKey) $(e.delegateTarget).sortable("disable");
}).on("dragend", "#article-file-container a", function(e) {
    $(e.delegateTarget).sortable("enable");
}).sortable({
    items: ".sortable",
    connectWith: "#body, #excerpt"/*,
    remove: function() {$(this).sortable("cancel")}*/
});
