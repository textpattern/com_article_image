(function () {
  function comArticleImageFormat(format, data) {
    var ids = [], text = "";
    if (format.match(/\{##\}/)) {
      data.forEach(function (img) {
        ids.push(img.id);
      });
      text = format.replace(/\{##\}/g, ids.join(","));
    } else data.forEach(function (img) {
      if (!img.id) format = imageLink ? imageLink : '<img src="{src}" srcset="{srcset}" sizes="{sizes}" title="{title}" alt="{alt}" height="{h}" width="{w}" />';
      let chunk = img.id ? format.replace(/\{#\}/g, img.id) : format;
      for (let [key, value] of Object.entries(img)) if (typeof value == "undefined") {
        chunk = chunk.replace(new RegExp("\\s+\\w+=[\"']{" + key + "}[\"']", "g"), "").replace(new RegExp("{" + key + "}", "g"), "");
      } else {
        let val = value.toString().replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
        chunk = chunk.replace(new RegExp("{" + key + "}", "g"), val)
      }
      text += chunk;
    });
    return text;
  }

  function comReadfiles(files, input) {
    let formData = new FormData(), count = 0;

    for (let i = 0; i < files.length; i++) {
      if (files[i].type.match(/^image\//) && files[i].size <= textpattern.prefs.max_file_size) {
        formData.append("thefile[]", files[i]);
        count++;
      }
    }

    let text = "Upload " + count + " image" + (count == 1 ? "" : "s") + "?";
    if (!count || !window.confirm(text)) return 0;

    formData.append("_txp_token", textpattern._txp_token);
    $(input).prop("disabled", true);

    $.ajax({
      url: "index.php?event=image&step=image_insert&app_mode=async&com=article_image",
      type: "POST",
      data: formData,
      async: true,
      success: function (data) {
        let text = typeof comArticleImage == "undefined" ? "" : comArticleImageFormat(imageTag, comArticleImage);
        textpattern.Relay.data.fileid = comArticleImage = [];
        $(input).prop("disabled", false);
        comInsertAtCursor(input, text);
        textpattern.Console.announce("uploadEnd");
      },
      cache: false,
      contentType: false,
      processData: false
    });
    return count;
  }

  function comInsertAtCursor(input, textToInsert) {
    const [start, end] = [input.selectionStart, input.selectionEnd];
    input.setRangeText(textToInsert, start, end, "end");
    // Notify any possible listeners of the change
    const e = new Event("input", { "bubbles": true, "cancelable": false });
    input.dispatchEvent(e);
  }

  function comArticleImagePreview(input) {
    let createObjectURL = (window.URL || window.webkitURL || {}).createObjectURL

    if (createObjectURL && input.files.length) {
      $(input.files).each(function () {
        let type = this.type.match(/^image\//), size = this.size <= textpattern.prefs.max_file_size;
        if (!type) {
          textpattern.Console.addMessage(['<strong>' + textpattern.encodeHTML(this.name) + '</strong> - ' + textpattern.gTxt('only_graphic_files_allowed'), 1], 'comImageUpload');
        } else if (!size) {
          textpattern.Console.addMessage(['<strong>' + textpattern.encodeHTML(this.name) + '</strong> - ' + textpattern.gTxt('upload_err_form_size'), 1], 'comImageUpload');
        } else {
          let src = createObjectURL(this);
          p = comArticleImageTile({ src: src, title: this.name }, { className: "sortable local upload", file: this });
          $("#article-file-container").append(p);
        }
      });
      textpattern.Console.announce('comImageUpload');
    }
  }

  function comArticleImageTile(atts, pAtts) {
    let button = $("<button class=\"destroy\" title=\"" + textpattern.gTxt("delete") + "\"><span class=\"ui-icon ui-icon-close\">" + textpattern.gTxt("delete") + "</span></button>");
    let img = $("<img />").attr("loading", "lazy").attr(atts), a = $("<a />").attr({"href": atts.src, target: "com_article_image"}).append(img);
    let p = document.createElement("p");
    for (let prop in pAtts) { p[prop] = pAtts[prop]; }
    return $(p).data("id", "#").append(a).append(button);
  }

  $("#article_form").on("submit", function () {
    let src = [], dataTransfer = new DataTransfer(),
      val = document.getElementById("article-image").value, tags = [];
    let i = 0, j = 0;

    $("#article-file-container").find("p.upload").each(function () {
      if (this.file) {
        dataTransfer.items.add(this.file);
        tags.push("@"+(i++));
      } else $(this).find("img").each(function () {
        let url = $(this).attr("src"), alt = $(this).attr("alt"), title = $(this).attr("title");
        src.push({ url: url, alt: alt, title: title });
        tags.push("#"+(j++));
      });
    });

    document.getElementById("article-file-import").value = JSON.stringify(src);
    document.getElementById("article-file-input").files = dataTransfer.files;
    let k = 0, l = tags.length;
    document.getElementById("article-file-tags").value = val.replace(/(^|,)\s*#\s*(?=$|,)/g, (m, b) => b + (k < l ? tags[k++] : 0));
  });

  $("#body, #excerpt").on("dragover", function (evt) {
    e = evt.originalEvent;
    if (e.dataTransfer.types.includes("Files")) {
      evt.stopPropagation();
      evt.preventDefault();
      e.dataTransfer.dropEffect = "copy";
    }
  }).on("drop", function (evt) {
    let e = evt.originalEvent, count = 0;
    if (e.dataTransfer.files.length && document.getElementById("article-file-input")) {//console.log(e.dataTransfer.files)
      count = comReadfiles(e.dataTransfer.files, this);
    }
    if (count)
      e.preventDefault();
    else {
      let parser = new DOMParser();
      let doc = parser.parseFromString(e.dataTransfer.getData("text/html"), "text/html");
      let img = $(doc.images);
      var text = "";
      if (img.length) {
        img.each(function (index) {
          let me = $(this);
          if (me.attr("src") || me.attr("srcset")) {
            let atts = {
              src: me.attr("src"),
              srcset: me.attr("srcset"),
              sizes: me.attr("sizes"),
              alt: me.attr("alt"),
              title: me.attr("title"),
              h: me.attr("height"),
              w: me.attr("width")
            };
            text += comArticleImageFormat(imageLink, [atts]);
          }
        });
      }
      if (text || !this.setRangeText) {
        e.preventDefault();
        comInsertAtCursor(this, text || e.dataTransfer.getData("text/plain"));
      }
    }
  }).sortable({
    receive: function (e) {
      let img = $(e.originalEvent.target), data = img.data();
      let src = data.id ? imageDir + "/" + data.id + data.ext : img.attr("src");
      let ins = [{ alt: img.attr("alt"), id: data.id, w: data.width, h: data.height, src: src }];
      comInsertAtCursor(this, comArticleImageFormat(imageTag, ins))
    }
  });

  $("#txp-image-group-content").on("dragenter", "#article-file-input-label", function (evt) {
    $(this).addClass("dragging");
  }).on("dragleave", "#article-file-input-label", function (evt) {
    $(this).removeClass("dragging");
  }).on("dragover", "#article-file-input-label, #article-file-container", function (evt) {
    evt.preventDefault();
    evt.originalEvent.dataTransfer.dropEffect = "copy";
  }).on("drop", "#article-file-input-label, #article-file-container", function (evt) {//console.log(evt.originalEvent.dataTransfer)
    evt.preventDefault();
    evt.stopPropagation();
    $(this).removeClass("dragging");
    let e = evt.originalEvent;
    const dragged = e.dataTransfer.getData("text/html") || e.target;
    let parser = new DOMParser();
    let doc = parser.parseFromString(dragged, "text/html");
    let imgs = $(doc.images);
    if (imgs.length) {
      imgs.each(function () {
        let atts = { src: $(this).attr("src"), alt: $(this).attr("alt"), title: $(this).attr("title") };
        let p = comArticleImageTile(atts, {className: "sortable remote upload"});
        $("#article-file-container").append(p.data("id", "#"));
      });
    } else if (e.dataTransfer.types.includes("Files")) {
      comArticleImagePreview(e.dataTransfer);
    }
    $("#txp-image-group-content").triggerHandler("sortstop");
  }).on("change", "#article-file-input", function (e) {
    comArticleImagePreview(this);
    this.value = null;
    $("#txp-image-group-content").triggerHandler("sortstop");
  }).on("click", ".com-image-container p button.destroy", function (e) {
    e.preventDefault();
    $(this).parent().remove();
  }).on("click", "#article-file-container .destroy", function (e) {
    $("#txp-image-group-content").triggerHandler("sortstop");
  }).on("click", "#article-file-select .destroy", function (e) {
    let count = $("#article-file-select").data("count");
    $("#article-file-select").data("count", count - 1).trigger("refresh");
  }).on("dragstart", "#article-file-container a, #article-file-select a", function (e) {
    let dragged = e.originalEvent.dataTransfer.getData("text/html") || e.originalEvent.target;
    let imgs = $(dragged).find("img");
    let data = [];
    imgs.each(function () {
      let src = $(this).data("id") ? imageDir + "/" + $(this).data("id") + $(this).data("ext") : $(this).attr("src");
      data.push({ alt: $(this).attr("alt"), id: $(this).data("id"), w: $(this).data("width"), h: $(this).data("height"), src: src });
    })
    e.originalEvent.dataTransfer.setData("text/plain", comArticleImageFormat(imageTag, data));
    e.originalEvent.dataTransfer.setData("text/html", "");
  }).on("sortstop", function (e, ext) {
    let myContainer = $("#article-file-container"), img = $("#article-image");
    let val = $("#article-image").val().trim().split(/\s*,\s*/), list = [];
    myContainer.children("p.sortable").each(function () {
      list.push(String($(this).data("id")));
    });
    if (ext === true) {
      val = val.filter(id => id.match(/^\d+\s*\-[+-]?\s*\d+$/) || list.indexOf(id) !== -1);
      img.val(val.join());
      let select = $("#article-file-select");
      list.forEach(function (id) {
        select.children("p[data-id='" + $.escapeSelector(id) + "']").remove();
      })
    } else img.val(list.join());
    $(img).each(function() {this.setCustomValidity(""); this.valid = this.value;});
    $(this).sortable("refresh");
  }).on("click", "#article-file-empty", function (e) {
    e.preventDefault();
    $("#article-file-select p").remove(e.originalEvent.shiftKey ? ":hidden" : ":visible");
    $("#article-file-name").trigger("reset");
  }).on("click", "#article-file-select a", function (e) {
    e.preventDefault();
    if (e.originalEvent) {
      let count = $("#article-file-select").data("count");
      $("#article-file-select").data("count", count - 1).trigger("refresh");
    }
    let myContainer = $("#article-file-container");
    $(this).parent().addClass("sortable").appendTo(myContainer);
    myContainer.scrollTop(myContainer.prop("scrollHeight"));
    $("#txp-image-group-content").triggerHandler("sortstop");
  }).on("click", "#article-file-add", function (e) {
    e.preventDefault();
    let sel = e.originalEvent.shiftKey ? "#article-file-select>p:hidden>a" : "#article-file-select>p:visible>a";
    $(sel).trigger("click").parent().show();
    $("#article-file-name").trigger("reset");
  }).on("reset", "#article-file-name", function (e) {
    this.value = this.filterValue;
    $(this).toggleClass("invert", this.invert).trigger("input");
  }).on("keydown", "#article-file-name", function (e) {
    if (e.originalEvent.key === "Escape") {
      e.preventDefault();
      if (e.originalEvent.shiftKey) {
        $(this).trigger("reset");
      } else {
        $("#article-file-select").empty().data("count", 0).trigger("refresh");
        $(this).each(function () {
          this.value = "";
          this.filterValue = "";
          this.invert = false;
        }).attr("title", null).removeClass("invert").trigger("validate");
      }
    }
    if (e.originalEvent.key !== "Enter") return;
    e.preventDefault();
    if (e.originalEvent.shiftKey) {
      $("#article-file-select p").toggle();
      $(this).toggleClass("invert").trigger("validate");
    } else {
      let val = this.value;
      this.filterValue = val;
      this.invert = $(this).hasClass("invert");
      this.setCustomValidity("");
      $.ajax({
        url: "index.php?event=article&step=com_article_image_fetch",
        type: "POST",
        data: { image_name: this.value, ids: $("#article-image").val(), _txp_token: textpattern._txp_token, invert: this.invert ? 1 : 0 },
        success: function (data) {
          $("#article-file-name").attr("title", val);
          $("#article-file-select").html($(data.join(""))).data("count", data.length).trigger("refresh");
        }
      });
    }
  }).on("input", "#article-file-name", function (e) {
    if (typeof this.filterValue == "undefined") this.filterValue = "";
    let invert = $(this).hasClass("invert");
    let val = this.value, count = 0,
      sel = invert ? ":not([title*='" + $.escapeSelector(val) + "' i])" : "[title*='" + $.escapeSelector(val) + "' i]",
      p = $("#article-file-select>p");

    if (val == "" || this.invert && val.includes(this.filterValue) || !this.invert && this.filterValue.includes(val)) {
      if (invert == !!this.invert) count = p.show().length;
      else p.hide();
    } else p.each(function () {
      if ($(this).is(sel)) { $(this).show(); count++; }
      else $(this).hide();
    });
    $(this).trigger("validate");
    $("#article-file-select").data("count", count).trigger("refresh");
  }).on("validate", "#article-file-name", function (e) {
    if (typeof this.filterValue == "undefined") this.filterValue = "";
    let invert = $(this).hasClass("invert"), val = this.value;
    if (invert == !!this.invert && (!invert && val.includes(this.filterValue) || invert && this.filterValue.includes(val))) this.setCustomValidity("");
    else this.setCustomValidity(this.filterValue);
  }).on("refresh", "#article-file-select", function () {
    $("#article-file-action").toggleClass("invisible", !$(this).data("count"));
  }).on("input", "#article-image", function () {
    this.setCustomValidity(this.value == this.valid ? "" : textpattern.gTxt("update")+" (Shift+Enter)");
  }).on("keydown", "#article-image", function (e) {
    if (e.originalEvent.key !== "Enter") return;
    let val = $(this).val();
    if (val === "") this.setCustomValidity("");
    if (e.originalEvent.shiftKey) {
      e.preventDefault();
      if (val !== "") {
        $.ajax({
          url: "index.php?event=article&step=com_article_image_update",
          type: "POST",
          data: { image_name: "", ids: val, _txp_token: textpattern._txp_token },
          success: function (data) {
            let container = $("#article-file-container");
            let upload = $("<div />").append(container.children("p.upload"));
            container.html($(data.join("")));
            let children = container.children("div");
            upload.children("p").each(function(idx) {
              children.eq(idx).replaceWith(this);
            });
            upload.remove();
            container.children("div").remove();
            $("#txp-image-group-content").triggerHandler("sortstop", true);
          }
        });
      } else {
        this.valid = this.value;
        $("#article-file-container").empty();
      }
    }
  }).on("mousedown", ".sortable", function (e) {
    if (e.originalEvent.shiftKey) $(e.delegateTarget).sortable("disable");
  }).on("dragend", "#article-file-container a", function (e) {
    $(e.delegateTarget).sortable("enable");
  }).sortable({
    items: ".sortable",
    connectWith: "#body, #excerpt"/*,
    remove: function() {$(this).sortable("cancel")}*/
  });
  document.addEventListener("securitypolicyviolation", (e) => {
    if (e.violatedDirective == "img-src") {
      let img = $("#article-file-container img[src='"+$.escapeSelector(decodeURIComponent(e.blockedURI))+"']");
      img.each(function() {
        this.parentElement.style.height = imageH+"px";
        this.parentElement.style.width = imageW+"px";
      });
    }
  });
}).apply()