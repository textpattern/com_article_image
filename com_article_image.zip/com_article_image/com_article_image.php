<?php
/**
 * com_article_image
 *
 * A Textpattern CMS plugin for inserting/uploading article images:
 *  -> Upload images directly in the Write panel
 *  -> Drag/drop images from Txp/your computer/other web pages
 *  -> Drag images directly into article fields to insert/upload
 *
 * @author Textpattern Community
 * @link   https://github.com.com/textpattern
 */
if (txpinterface === 'admin') {
    new com_article_image();
}

class com_article_image
{
    protected $event = 'com_article_image';
    protected $privs = '1,2,3,4,5,6';
    protected $pluginpath = 'plugins';

    /**
     * Constructor
     */
    public function __construct()
    {
        global $event, $step, $path_to_site;

        add_privs('plugin_prefs.'.$this->event, $this->privs);
        add_privs($this->event, $this->privs);
        add_privs('prefs.'.$this->event, $this->privs);

        register_callback(array($this, 'prefs'), 'plugin_prefs.'.$this->event);
        register_callback(array($this, 'install'), 'plugin_lifecycle.'.$this->event);
        register_callback(array($this, 'prefs_save'), 'prefs', 'save', 0); // txp 4.9+

        if ($event === 'article' && has_privs('article.edit.own')) {
            register_callback(array($this, 'upload'), 'article_ui', 'article_image');
            register_callback(array($this, 'save'), 'article_posted');
            register_callback(array($this, 'save'), 'article_saved');
            register_callback(array($this, 'head'), 'admin_side', 'head_end');
            register_callback(array($this, 'js'), 'admin_side', 'body_end');

            if ($step == 'com_article_image_fetch' || $step == 'com_article_image_update') {
                register_callback(array($this, 'fetch'), 'article', $step, 1);
            }
        }

        if (gps('com') === 'article_image') {
            register_callback(array($this, 'post_upload'), 'site.update', 'image_uploaded');
        }

        $this->pluginpath = str_replace($path_to_site, '..', PLUGINPATH);//dmp($pluginpath);
//        $this->install();
        if (get_pref('com_article_image_search', null) === null)
            set_pref('com_article_image_search', 'name, id', $this->event, PREF_PLUGIN, 'text_input', 400, PREF_PRIVATE);
        if (get_pref('com_article_image_limit', null) === null)
            set_pref('com_article_image_limit', 0, $this->event, PREF_PLUGIN, 'number', 450, PREF_PRIVATE);
        if (get_pref('com_article_image_internal', null) === null)
            set_pref('com_article_image_internal', '<txp:image id="{#}" />', $this->event, PREF_PLUGIN, 'longtext_input', 500, PREF_PRIVATE);
        if (get_pref('com_article_image_external', null) === null)
            set_pref('com_article_image_external', '', $this->event, PREF_PLUGIN, 'longtext_input', 700, PREF_PRIVATE);
    }

    /**
     * Installs prefs if not already defined.
     *
     * @param string $evt Admin-side event
     * @param string $stp Admin-side step
     */
    public function install($evt = '', $stp = '')
    {
        if ($stp == 'deleted') {
            // Remove predecessor abc_article_image prefs too.
            safe_delete('txp_prefs', "name LIKE 'abc\_file\_%' OR name LIKE 'com\_article\_image\_%'");
            safe_delete('txp_lang', "name = 'instructions\_article\_image\_select'");
        } elseif ($stp == 'installed') {
            safe_update('txp_prefs', "event='".$this->event."'", "name LIKE 'com\_article\_image\_%'");

            if (get_pref('com_article_image_limit', null) !== null)
                safe_delete('txp_prefs', "name='com\_article\_image\_limit'");
        }
    }

    /**
     * Redirect to the preferences panel
     */
    public function prefs()
    {
        header('Location: ?event=prefs#prefs_group_com_article_image');
        echo
            '<p id="message">'.n.
            '   <a href="?event=prefs#prefs_group_com_article_image">'.gTxt('continue').'</a>'.n.
            '</p>';
    }

    /**
     * Sanitizes some plugin preferences
     */
    public function prefs_save($evt, $stp, &$post)
    {
        global $DB;

        if (!isset($post['com_article_image_search'])) {
            return;
        }

        $table = safe_pfx('txp_image');
        $columns = do_list_unique(strtolower($post['com_article_image_search']));
        $fields = getThings("SELECT `COLUMN_NAME` FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='$DB->db' AND `TABLE_NAME`='txp_image'");
        $post['com_article_image_search'] = implode(', ', array_intersect($columns, $fields));
    }

    /**
     * Inject style rules.
     *
     * @return string CSS style block
     */
    public function head()
    {
        global $img_dir;

        gTxtScript(array('delete', 'update'));

        if (class_exists('\Textpattern\UI\Style')) {
            echo Txp::get('\Textpattern\UI\Style')->setSource("$this->pluginpath/com_article_image/style.css"), n;
        } else {
            echo n, <<<EOCSS
<link rel="stylesheet" media="screen" href="$this->pluginpath/com_article_image/style.css">
EOCSS;
        }

        $internal_tag = escape_js(get_pref('com_article_image_internal', '<txp:image id="{#}" />'));
        $external_tag = escape_js(get_pref('com_article_image_external'));
        $img_location = escape_js(ihu.$img_dir);
        $img_h = intval(get_pref('thumb_h')) or $img_h = 128;
        $img_w = intval(get_pref('thumb_w')) or $img_w = 128;

        $content = <<<EOJS
const imageTag = "{$internal_tag}",
    imageLink = "{$external_tag}",
    imageDir = "{$img_location}";
document.querySelector(":root").style.setProperty("--thumb-h", "{$img_h}px");
document.querySelector(":root").style.setProperty("--thumb-w", "{$img_w}px");
EOJS;

        if (class_exists('\Textpattern\UI\Script')) {
            echo Txp::get('\Textpattern\UI\Script')->setRoute(array('article'))->setContent($content, false), n;
        } else {
            script_js($content , false, array('article'));
        }
    }
    /**
     * Inject the JavaScript
     *
     * @return string HTML &lt;script&gt; tag
     */
    public function js()
    {
        if (class_exists('\Textpattern\UI\Script')) {
            echo Txp::get('\Textpattern\UI\Script')->setRoute(array('article'))->setSource("$this->pluginpath/com_article_image/script.js"), n;
        } else {
            echo n.'<script defer src="'.$this->pluginpath.'/com_article_image/script.js"></script>';
        }
    }

    /**
     * Send script response after each upload completes
     *
     * @param string $evt Admin-side event
     * @param string $stp Admin-side step
     * @param array  $rs  Uploaded image metadata record
     */
    public function post_upload($evt, $stp, $rs)
    {
        global $img_dir;

        $img = array_intersect_key($rs, array(
            'id'  => null,
            'alt' => null,
            'h'   => null,
            'w'   => null))
        + array(
            'src' => ihu.$img_dir.'/'.$rs['id'].$rs['ext']
        );

        send_script_response('comArticleImage = ['.json_encode($img).'].concat(typeof comArticleImage == "undefined" ? [] : comArticleImage)');
    }

    /**
     * Fetch images from db
     *
     * @param string $evt Admin-side event
     * @param string $stp Admin-side step
     * @param array  $ids  Image ids to exclude/include
     */
    public function fetch($evt, $stp, $ids = null)
    {
        static $steps = array(
            'com_article_image_fetch'  => true,
            'com_article_image_update' => true,
            'article_image'            => false,
        );

        if (!isset($steps[$stp])) {
            return;
        }

        bouncer($stp, $steps);
        $json = $stp != 'article_image';
        isset($ids) or $ids = ps('ids');

        if ($stp == 'com_article_image_fetch') {
            $not = 'NOT';
            $class = '';
        } else {
            $not = '';
            $class = 'sortable';
        }

        if (empty($ids) && empty($not)) {
            if ($json) {
                send_json_response(array());
                exit;
            }

            return array();
        }

        $ids = array_filter(do_list($ids, array(',', '-')));
        $dbids = implode(',', array_map('intval', array_filter($ids, 'is_numeric')));
        $fields = do_list_unique(get_pref('com_article_image_search') ? get_pref('com_article_image_search') : get_pref('search_options_image'));
        $images = $crit = array();
        $sname = doSlash(ps('image_name'));
        $invert = ps('invert') ? 'NOT' : '';

        if ($dbids || $not) {
            if ($sname !== '') foreach ($fields as $field) {
                $field = doSlash($field);
                $crit[] = "`$field` LIKE '%$sname%'";
            }

            $crit = $crit ? implode(' OR ', $crit) : '1';
            $filter = ($dbids ? "id $not IN($dbids)" : '1').($crit ? " AND $invert($crit)" : '');
            $sort = $not ? get_pref('image_sort_column', 'id').' '.get_pref('image_sort_dir', 'DESC') : "FIELD(id, $dbids)";
            $limit = intval(get_pref('com_article_image_limit', 0));

            $rows = array_column(safe_rows('*', 'txp_image', $filter." ORDER BY $sort".($limit ? " LIMIT $limit" : '')), null, 'id');
            $not and $ids = array_keys($rows);
        } else {
            $rows = array();
        }

        foreach ($ids as $id) if (isset($rows[$id])) {
            $row = $rows[$id];
            $ptitle = array();

            foreach ($fields as $field) if ($row[$field] !== '') {
                $ptitle[] = $row[$field];
            }

            extract($row);
            $thumbnail or $thumb_w = $w and $thumb_h = $h;
            $alt = txpspecialchars($alt ? $alt : $name);

            $images[] = '<p class="'.$class.'" data-id="'.$id.'" title="'.txpspecialchars(implode('|', $ptitle)).'">'
                .'<a href="index.php?event=image&step=image_edit&id='.$id.'" title="'.txpspecialchars("$name ($id)").'" target="com_article_image">'
                .'<img src="'.imagesrcurl($id, $ext, $thumbnail).'" width="'.$thumb_w.'" height="'.$thumb_h.'" data-id="'.$id.'" data-ext="'.$ext.'" data-width="'.$w.'" data-height="'.$h.'" alt="'.$alt.'" loading="lazy" />'
                .'</a><button class="destroy" title="'.gTxt('delete').'"><span class="ui-icon ui-icon-close">'.gTxt('delete').'</span></button></p>';
        } elseif ($id == "#") {
            $images[] = '<div></div>';
        } elseif (!is_numeric($id)) {
            $id = txpspecialchars($id);
            $src = preg_match('/^https?:/i', $id) ? $id : '../'.$id;
            $images[] = '<p class="'.$class.'" data-id="'.$id.'" title="'.$id.'"><a href="'.$src.'" title="'.$id.'" target="com_article_image">'
                .'<img src="'.$src.'" data-id="0" data-ext="" data-width="" data-height="" alt="'.$id.'" loading="lazy" />'
                .'</a><button class="destroy" title="'.gTxt('delete').'"><span class="ui-icon ui-icon-close">'.gTxt('delete').'</span></button></p>';
        }

        if ($json) {
            send_json_response($images);
            exit;
        }

        return $images;
    }

    /**
     * Alter the upload form markup to include the image thumbs and dropzone
     *
     * @param  string $evt  Admin-side event
     * @param  string $stp  Admin-side step
     * @param  array  $data Existing upload form markup
     * @param  array  $rs   Uploaded image metadata record
     * @return string       HTML
     */
    public function upload($evt, $stp, $data, $rs)
    {
        $images = !empty($rs['Image']) ? $this->fetch($evt, $stp, $rs['Image']) : array();
        $fields = get_pref('com_article_image_search') or $fields = get_pref('search_options_image');

        $article_image = '<div id="article-file-container" class="com-image-container">'.n
                .implode(n, $images).n
            .'</div>'.n;

        $upload_images = (has_privs('image.edit') && is_writeable(IMPATH) ? inputLabel(
                'article-file-input',
                '<input id="article-file-input" type="file" name="article_file[]" multiple="multiple" accept="image/*" />'
                .'<input type="hidden" name="com_image_import" id="article-file-import" value="[]" />'.n
                .'<input type="hidden" name="com_image_tags" id="article-file-tags" value="" />'.n
                .'<label id="article-file-input-label" for="article-file-input" class="secondary-text">'
                .gTxt('com_article_image_dropzone')
                .'</label>'.n,
                gTxt('upload'),
                array('', 'instructions_article_image'),
                array('id' => 'article-file-drop', 'class' => 'txp-form-field article-image')
            ).n : '');

            $select_images = inputLabel(
            'article-file-name',
            '<input id="article-file-name" placeholder="'.txpspecialchars($fields).'" form="" type="text" size="32" />'.n,
            array(
                gTxt('search'),
                '<span id="article-file-action" class="invisible">'
                .'<button id="article-file-add" class="destroy"><span class="ui-icon ui-icon-plus">'.gTxt('add').'</span></button>'.gTxt('add')
                .'<button id="article-file-empty" class="destroy"><span class="ui-icon ui-icon-close">'.gTxt('delete').'</span></button>'.gTxt('delete')
                .'</span>'
            ),
            array('', 'instructions_article_image_select'),
            array('class' => 'txp-form-field article-image')
        ).n
        .'<div id="article-file-select" class="com-image-container"></div>'.n;

        return $data.n.$article_image.n
            .$upload_images
            .$select_images;
    }

    /**
     * [save description]
     * @param string $evt Admin-side event
     * @param string $stp Admin-side step
     * @param array  $rs  Uploaded image metadata record
     */
    public function save($event, $step, $rs)
    {
        global $tempdir;
        static $atts = array('src' => '', 'alt' => '', 'title' => false);

        if (!has_privs('image.edit')) {
            return;
        }
    
        bouncer($step, array($step=>true));
        $tmpdir = rtrim($tempdir, '/'.DS).DS;
        //$ids = array();
        $ids = do_list_unique(/*$rs['Image']*/ps('com_image_tags'));
        $ids = array_combine($ids, $ids);

        include_once txpath.DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'class.thumb.php';

        if (!empty($_FILES['article_file']['tmp_name'][0])) {
            $files = Txp::get('\Textpattern\Server\Files')->refactor($_FILES['article_file']);

            foreach ($files as $idx => $file) {
                if (isset($ids['@'.$idx])) {
                    $meta = array('alt' => $file['name']);  // @todo: caption, category?
                    $img_result = image_data($file, $meta);

                    if (is_array($img_result)) {
                        //list($message, $id) = $img_result;
                        //$ids[] = $id;
                        $ids['@'.$idx] = $img_result[1];
                    }
                } else unlink($file['tmp_name']);
            }
        }

        $import = json_decode(ps('com_image_import'), true) or $import = array();

        foreach ($import as $idx => $img) {
            if (isset($ids['#'.$idx])) {
                extract($img + $atts);
                $errorlevel = error_reporting();
                error_reporting(0);
                $file = file_get_contents($url);
                error_reporting($errorlevel);
            } else $file = false;
        
            if ($file !== false) {
                $url = parse_url($url);
                $pathinfo = pathinfo($url['path']);
                $name = $pathinfo['basename'];
                
                $tmp_name = $tmpdir.md5($name).'.tmp';
                $img_result = false;
                
                if (file_put_contents($tmp_name, $file) !== false) {
                    $img_result = image_data(
                        array('tmp_name' => $tmp_name, 'error' => 0, 'name' => $name),
                        array('alt' => $alt ? $alt : $name, 'caption' => $title),
                        0, false
                    );
                }
        
                if (is_array($img_result)) {
                    //$ids[] = $img_result[1];
                    $ids['#'.$idx] = $img_result[1];
                }
        
                if (file_exists($tmp_name)) {
                    unlink($tmp_name);
                }
            }
        }

        $ids = implode(',', $ids);
        //$ids = implode(',', do_list_unique($rs['Image'].','.$ids));
        // image_data alters $GLOBALS['ID']
        $GLOBALS['ID'] = intval($rs['ID']);

        safe_update('textpattern', "Image='".doSlash($ids)."'", 'ID='.$GLOBALS['ID']);
    }
}
