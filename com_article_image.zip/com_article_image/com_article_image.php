<?php
/**
 * com_article_image
 *
 * A Textpattern CMS plugin for inserting/uploading article images:
 *  -> Upload images directly in the Write panel
 *  -> Drag/drop images from Txp/your computer/other web pages
 *  -> Drag images directly into article fields to insert/upload
 *
 * @author Textpattern Community
 * @link   https://github.com.com/textpattern
 */
if (txpinterface === 'admin') {
    new com_article_image();
}

class com_article_image
{
    protected $event = 'com_article_image';
    protected $version = '0.2.2';
    protected $privs = '1,2,3,4,5,6';

    /**
     * Constructor
     */
    public function __construct()
    {
        global $event, $step;

        add_privs('plugin_prefs.'.$this->event, $this->privs);
        add_privs($this->event, $this->privs);
        add_privs('prefs.'.$this->event, $this->privs);

        register_callback(array($this, 'prefs'), 'plugin_prefs.'.$this->event);
        register_callback(array($this, 'install'), 'plugin_lifecycle.'.$this->event);

        if ($event === 'article' && has_privs('article.edit.own') && has_privs('image.edit.own')) {
            register_callback(array($this, 'upload'), 'article_ui', 'article_image');
            register_callback(array($this, 'save'), 'article_posted');
            register_callback(array($this, 'save'), 'article_saved');
            register_callback(array($this, 'head'), 'admin_side', 'head_end');
            register_callback(array($this, 'js'), 'admin_side', 'body_end');

            if ($step == 'com_article_image_fetch') {
                register_callback(array($this, 'fetch'), 'article', $step, 1);
            }
        }

        if (gps('com') === 'article_image') {
            register_callback(array($this, 'post_upload'), 'site.update', 'image_uploaded');
        }


        $this->install();
    }

    /**
     * Installs prefs if not already defined.
     *
     * @param string $evt Admin-side event
     * @param string $stp Admin-side step
     */
    public function install($evt = '', $stp = '')
    {
        if ($stp == 'deleted') {
            // Remove predecessor abc_article_image prefs too.
            safe_delete('txp_prefs', "name LIKE 'abc\_file\_%' OR name LIKE 'com\_article\_image\_%'");
        } elseif ($stp == 'installed') {
            safe_update('txp_prefs', "event='".$this->event."'", "name LIKE 'com\_article\_image\_%'");

            if (get_pref('com_article_image_limit', null) === null)
                set_pref('com_article_image_limit', 12, $this->event, PREF_PLUGIN, 'text_input', 300, PREF_PRIVATE);
            if (get_pref('com_article_image_search', null) === null)
                set_pref('com_article_image_search', 'name, id', $this->event, PREF_PLUGIN, 'text_input', 400, PREF_PRIVATE);
            if (get_pref('com_article_image_internal', null) === null)
                set_pref('com_article_image_internal', '<txp:image id="{#}" />', $this->event, PREF_PLUGIN, 'longtext_input', 500, PREF_PRIVATE);
            if (get_pref('com_article_image_external', null) === null)
                set_pref('com_article_image_external', '', $this->event, PREF_PLUGIN, 'longtext_input', 700, PREF_PRIVATE);
        }
    }

    /**
     * Redirect to the preferences panel
     */
    public function prefs()
    {
        header('Location: ?event=prefs#prefs_group_com_article_image');
        echo
            '<p id="message">'.n.
            '   <a href="?event=prefs#prefs_group_com_article_image">'.gTxt('continue').'</a>'.n.
            '</p>';
    }

    /**
     * Inject style rules.
     *
     * @return string CSS style block
     */
    public function head()
    {
        global $img_dir;

        $sel = 'p.matching:not(.hidden)';
        $limit = intval(get_pref('com_article_image_limit'));

        if (!$limit) {
            $paginator = new \Textpattern\Admin\Paginator('image');
            $limit = $paginator->getLimit();
        }

        for ($i = 0; $i < $limit; $i++) $sel .= '~p.matching:not(.hidden)';

        $content = "#article-file-select $sel {display: none}";

        if (class_exists('\Textpattern\UI\Style')) {
            echo Txp::get('\Textpattern\UI\Style')->setSource("plugins/com_article_image/style.css"), n;
            echo Txp::get('\Textpattern\UI\Style')->setContent($content), n;
        } else {
            echo n, <<<EOCSS
<link rel="stylesheet" media="screen" href="plugins/com_article_image/style.css">
EOCSS;
            echo '<style>' . $content . '</style>', n;
        }

        $internal_tag = escape_js(get_pref('com_article_image_internal', '<txp:image id="{#}" />'));
        $external_tag = escape_js(get_pref('com_article_image_external'));
        $img_location = escape_js(ihu.$img_dir);

        $content = <<<EOJS
var imageTag = "{$internal_tag}",
    imageLim = "{$limit}",
    imageLink = "{$external_tag}",
    imageDir = "{$img_location}";
EOJS;

        if (class_exists('\Textpattern\UI\Script')) {
            echo Txp::get('\Textpattern\UI\Script')->setRoute(array('article'))->setContent($content, false), n;
        } else {
            script_js($content , false, array('article'));
        }
    }
    /**
     * Inject the JavaScript
     *
     * @return string HTML &lt;script&gt; tag
     */
    public function js()
    {
        if (class_exists('\Textpattern\UI\Script')) {
            echo Txp::get('\Textpattern\UI\Script')->setRoute(array('article'))->setSource("plugins/com_article_image/script.js"), n;
        } else {
            echo n.'<script defer src="plugins/com_article_image/script.js"></script>';
        }
    }

    /**
     * Send script response after each upload completes
     *
     * @param string $evt Admin-side event
     * @param string $stp Admin-side step
     * @param array  $rs  Uploaded image metadata record
     */
    public function post_upload($evt, $stp, $rs)
    {
        global $img_dir;

        $img = array_intersect_key($rs, array(
            'id'  => null,
            'alt' => null,
            'h'   => null,
            'w'   => null))
        + array(
            'src' => ihu.$img_dir.'/'.$rs['id'].$rs['ext']
        );

        send_script_response('comArticleImage = ['.json_encode($img).'].concat(typeof comArticleImage == "undefined" ? [] : comArticleImage)');
    }

    /**
     * Fetch images from db
     *
     * @param string $evt Admin-side event
     * @param string $stp Admin-side step
     * @param array  $ids  Image ids to exclude/include
     */
    public function fetch($evt, $stp, $ids = array())
    {
        if ($stp == 'com_article_image_fetch') {
            $ids = do_list_unique(ps('ids'));
            $not = 'NOT';
            $class = 'matching';
        } else {
            $not = '';
            $class = 'sortable';
        }

        foreach ($ids as &$id) {
            if (!is_numeric($id)) {
                $id = fetch('id', 'txp_image', 'name', $id);
            }

            $id = (int)$id;
        }

        $ids = implode(',', array_filter($ids));

        if (empty($ids) && $stp == 'article_image') {
            return array();
        }

        $fields = do_list_unique(get_pref('com_article_image_search') ? get_pref('com_article_image_search') : get_pref('search_options_image'));
        $images = $crit = array();
        $sname = doSlash(ps('image_name'));

        if ($sname !== '') foreach ($fields as $field) {
            $field = doSlash($field);
            $crit[] = "`$field` LIKE '%$sname%'";
        }

        $crit = implode(' OR ', $crit);
        $filter = ($ids ? "id $not IN($ids)" : '1').($crit ? " AND ($crit)" : '');
        $sort = $stp == 'article_image' ? "FIELD(id, $ids)" : get_pref('image_sort_column', 'id').' '.get_pref('image_sort_dir', 'DESC');

        $rows = safe_rows('*', 'txp_image', $filter." ORDER BY $sort");

        foreach ($rows as $row) {
            $ptitle = array();

            foreach ($fields as $field) if ($row[$field] !== '') {
                $ptitle[] = $row[$field];
            }

            extract($row);

            $images[] = '<p class="'.$class.'" data-id="'.$id.'" title="'.txpspecialchars(implode('|', $ptitle)).'"><a href="index.php?event=image&step=image_edit&id='.$id.'" title="'.txpspecialchars($name).' ('.$id.')">'
                .'<img src="'.imagesrcurl($id, $ext, $thumbnail).'" data-id="'.$id.'" data-ext="'.$ext.'" data-width="'.$w.'" data-height="'.$h.'" alt="'.txpspecialchars($alt).'" loading="lazy" />'
                .'</a><button class="destroy"><span class="ui-icon ui-icon-close">'.gTxt('delete').'</span></button></p>';
        }

        if ($stp == 'com_article_image_fetch') {
            send_json_response($images);
            exit;
        }

        return $images;
    }

    /**
     * Alter the upload form markup to include the image thumbs and dropzone
     *
     * @param  string $evt  Admin-side event
     * @param  string $stp  Admin-side step
     * @param  array  $data Existing upload form markup
     * @param  array  $rs   Uploaded image metadata record
     * @return string       HTML
     */
    public function upload($evt, $stp, $data, $rs)
    {
        $images = !empty($rs['Image']) ? $this->fetch($evt, $stp, do_list($rs['Image'])) : array();
        $article_image = '<div id="article-file-container">'.implode(n, $images).'</div>'.n;
        $fields = get_pref('com_article_image_search') or $fields = get_pref('search_options_image');

        $select_images = inputLabel(
            'article-file-name',
            '<input id="article-file-name" autocomplete="off" placeholder="'.txpspecialchars($fields).'" form="" type="text" size="32" />'.n, gTxt('search'),
            array('', 'instructions_article_image'),
            array('class' => 'txp-form-field article-image')
        ).n
        .'<div id="article-file-select"></div>'.n;

        return $data.n.$article_image.n
        .inputLabel(
            'article-file-input',
            '<button id="article-file-reset" class="destroy"><span class="ui-icon ui-icon-close">'.gTxt('delete').'</span></button>'.n.
            '<input id="article-file-input" type="file" name="article_file[]" multiple="multiple" accept="image/*" onchange="comArticleImagePreview(this)" />'
            .'<p class="secondary-text">'.gTxt('com_article_image_dropzone').'</p>'.n
            .'<div id="article-file-preview"></div>'.n, gTxt('upload'),
            array('', 'instructions_article_image'),
            array('id' => 'article-file-drop', 'class' => 'txp-form-field article-image')
        ).n.$select_images;
    }

    /**
     * [save description]
     * @param string $evt Admin-side event
     * @param string $stp Admin-side step
     * @param array  $rs  Uploaded image metadata record
     */
    public function save($evt, $stp, $rs)
    {
        if (empty($_FILES['article_file']['tmp_name'][0]) || !has_privs('image.edit')) {
            return;
        }

        include_once 'lib'.DIRECTORY_SEPARATOR.'class.thumb.php';

        $ids = array();
        $files = Txp::get('\Textpattern\Server\Files')->refactor($_FILES['article_file']);

        foreach ($files as $file) {
            $meta = array('alt' => $file['name']);  // @todo: caption, category?
            $img_result = image_data($file, $meta);

            if (is_array($img_result)) {
                list($message, $id) = $img_result;
                $ids[] = $id;
            }
        }

        $GLOBALS['ID'] = intval($rs['ID']);
        $ids = implode(',', $ids);
        $ids = implode(',', do_list_unique($rs['Image'].','.$ids));

        safe_update('textpattern', "Image='".doSlash($ids)."'", 'ID='.$GLOBALS['ID']);
    }
}
